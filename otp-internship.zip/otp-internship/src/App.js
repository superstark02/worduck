import './App.css';
import React, { useRef } from 'react';
import Otp from './Components/Otp';

class App extends React.Component {

  render() {
    return (
      <div>
        <Otp/>
      </div>
    );
  }
}

export default App;
